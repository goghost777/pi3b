let typingInProgress = false;
let isCancelled = false;

function updateHistory(history) {
    const div = document.getElementById("history");
    div.innerHTML = "";
    history.forEach(entry => {
        if (entry.role === "user") {
            const el = document.createElement("div");
            el.className = "entry";
            el.textContent = "You: " + entry.content;
            div.appendChild(el);
        }
    });
    div.scrollTop = div.scrollHeight;
}

function typeEffect(element, text, speed = 25) {
    element.textContent = "";
    let i = 0;
    typingInProgress = true;
    isCancelled = false;

    function typeChar() {
        if (isCancelled) {
            element.textContent += "\n[Cancelled]";
            typingInProgress = false;
            return;
        }

        if (i < text.length) {
            element.textContent += text.charAt(i);
            i++;
            element.scrollTop = element.scrollHeight;
            setTimeout(typeChar, speed);
        } else {
            typingInProgress = false;
        }
    }

    typeChar();
}

function cancelTyping() {
    if (typingInProgress) {
        isCancelled = true;
        document.getElementById("status").innerText = "Typing cancelled by user.";
    }
}

function sendMessage() {
    const sendBtn = document.getElementById("sendBtn");
    const status = document.getElementById("status");
    const msgBox = document.getElementById("message");
    const msg = msgBox.value;

    if (!msg.trim() || typingInProgress) return;

    sendBtn.disabled = true;
    status.innerText = "Please wait...";

    fetch("/chat", {
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `message=${encodeURIComponent(msg)}`
    })
    .then(res => res.json())
    .then(data => {
        updateHistory(data.history);
        typeEffect(document.getElementById("response"), "Assistant: " + data.response);
        msgBox.value = "";
        status.innerText = "";
    })
    .catch(err => {
        document.getElementById("response").textContent = "Error: " + err;
        status.innerText = "";
    });

    // Delay unlock after 5 seconds
    setTimeout(() => {
        sendBtn.disabled = false;
        status.innerText = "";
    }, 5000);
}

function clearHistory() {
    fetch("/clear", { method: "POST" })
    .then(res => res.json())
    .then(() => {
        updateHistory([]);
        document.getElementById("response").textContent = "";
    });
}

function startSpeech() {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Speech recognition not supported in this browser.");
        return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById("message").value = transcript;
    };

    recognition.onerror = function(event) {
        alert("Speech recognition error: " + event.error);
    };

    recognition.start();
}
