Raspberry Pi Framebuffer Copy
=============================
This program used for copy primary framebuffer to secondary framebuffer (eg. FBTFT). It require lastest raspberry pi firmware (> 2013-07-11) to working properly.

Build
-----

    $ mkdir build
    
    $ cd build
    
    $ cmake ..
    
    $ make 
